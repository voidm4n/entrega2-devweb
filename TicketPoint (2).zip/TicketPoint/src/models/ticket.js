const {Schema, model} = require ('mongoose');

const TicketSchema = new Schema ({
    tittle: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    }
}, {
    timestamps: true
})

module.exports = model('Ticket', TicketSchema);