const { Router } = require('express');
const router = Router();

router.get('/', (req, res) => {
    res.render('login')
});

router.get('/register', (req, res) => {
    res.render('register')
});

router.get('/home', (req, res) => {
    res.render('home')
});

router.get('/fechas', (req, res) => {
    res.render('fechas')
});

router.get('/boletos', (req, res) => {
    res.render('boletos')
});

router.get('/carrito', (req, res) => {
    res.render('carrito')
});

module.exports = router;