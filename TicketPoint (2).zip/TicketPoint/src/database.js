const mongoose = require('mongoose');

const TICKETPOINT_HOST = process.env.TICKETPOINT_HOST;
const TICKETPOINT_DATABASE = process.env.TICKETPOINT_DATABASE;

const MONGODB_URL = `mongodb://${TICKETPOINT_HOST}/${TICKETPOINT_DATABASE}`;


mongoose.connect(MONGODB_URL, {
    useUnifiedTopology: true,
    useNewUrlParser: true
})

    .then(db => console.log('Database is conected'))
    .catch(err => console.log(err));