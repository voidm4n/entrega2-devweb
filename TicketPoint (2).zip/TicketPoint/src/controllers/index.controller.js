
const control = {};

control.renderLogin = (res, req) => {
    res.render('login')
};

control.renderRegister = (res, req) => {
    res.render('register')
};



module.exports = control;